package com.notifly.backend.Verification.OTP;
import org.springframework.stereotype.Service;

import com.notifly.backend.Verification.Properties.TwilioProperties;
import com.twilio.rest.api.v2010.account.Message;

import lombok.RequiredArgsConstructor;

@Service
@RequiredArgsConstructor
public class WhatsAppService {

    private final TwilioProperties props;

    public void sendOtp(String mobile, String otp) {

        Message.creator(
            "whatsapp:+91" + mobile,
            null, props.getWhatsappFrom(),
            "Your OTP is *" + otp + "*\nValid for 5 minutes."
        ).create();
    }
}
