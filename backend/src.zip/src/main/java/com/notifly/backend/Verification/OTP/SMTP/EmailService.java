package com.notifly.backend.Verification.OTP.SMTP;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.mail.SimpleMailMessage;
import org.springframework.mail.javamail.JavaMailSender;
import org.springframework.stereotype.Service;

import lombok.RequiredArgsConstructor;
import lombok.extern.slf4j.Slf4j;

@Service
@RequiredArgsConstructor
@Slf4j
public class EmailService {

    private final JavaMailSender mailSender;
    private Logger log=LoggerFactory.getLogger(EmailService.class);

    public void sendOtp(String email, String otp) {

        SimpleMailMessage message = new SimpleMailMessage();
        message.setTo(email);
        message.setSubject("OTP Verification");
        message.setText("""
                Your OTP: %s

                Valid for 5 minutes.
                Do not share this OTP.
                """.formatted(otp));

        mailSender.send(message);

        log.info("OTP email sent to {}", email);
    }
}
