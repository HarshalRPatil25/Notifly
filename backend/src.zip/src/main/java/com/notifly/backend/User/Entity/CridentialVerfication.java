package com.notifly.backend.User.Entity;

import org.springframework.stereotype.Component;

import jakarta.persistence.Entity;
import jakarta.persistence.OneToOne;
import jakarta.persistence.Table;
import lombok.Data;

@Component
@Data
@Entity
@Table(name="verification")
public class CridentialVerfication {
    private boolean isMailVerified;
    private boolean isNumberVerified;
    
    @OneToOne
    private User user;
}
